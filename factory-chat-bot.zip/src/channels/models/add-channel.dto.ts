export class AddChannelDto {
   readonly name: string
   readonly tgId: string
}