export class AddUserDto {
   readonly name: string
   readonly rtole: string
   readonly tgId: string
   readonly phone: string
}