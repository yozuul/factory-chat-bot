export class AddFileDto {
   readonly name: string
   readonly tgId: string
   readonly areaId: number
}