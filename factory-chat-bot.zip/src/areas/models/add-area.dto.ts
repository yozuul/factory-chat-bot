export class AddAreaDto {
   readonly name: string
}