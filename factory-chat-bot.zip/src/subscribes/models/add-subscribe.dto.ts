export class AddSubscribeDto {
   readonly channelId: string
   readonly areaId: string
}